#include "s21_string.h"

#if defined(__APPLE__) || defined(__MACH__)
#define ERRLIST_SIZE 107
#define STR_ERRORS                                                             \
  {                                                                            \
    "Undefined error: 0", "Operation not permitted",                           \
        "No such file or directory", "No such process",                        \
        "Interrupted system call", "Input/output error",                       \
        "Device not configured", "Argument list too long",                     \
        "Exec format error", "Bad file descriptor", "No child processes",      \
        "Resource deadlock avoided", "Cannot allocate memory",                 \
        "Permission denied", "Bad address", "Block device required",           \
        "Resource busy", "File exists", "Cross-device link",                   \
        "Operation not supported by device", "Not a directory",                \
        "Is a directory", "Invalid argument", "Too many open files in system", \
        "Too many open files", "Inappropriate ioctl for device",               \
        "Text file busy", "File too large", "No space left on device",         \
        "Illegal seek", "Read-only file system", "Too many links",             \
        "Broken pipe", "Numerical argument out of domain", "Result too large", \
        "Resource temporarily unavailable", "Operation now in progress",       \
        "Operation already in progress", "Socket operation on non-socket",     \
        "Destination address required", "Message too long",                    \
        "Protocol wrong type for socket", "Protocol not available",            \
        "Protocol not supported", "Socket type not supported",                 \
        "Operation not supported", "Protocol family not supported",            \
        "Address family not supported by protocol family",                     \
        "Address already in use", "Can't assign requested address",            \
        "Network is down", "Network is unreachable",                           \
        "Network dropped connection on reset",                                 \
        "Software caused connection abort", "Connection reset by peer",        \
        "No buffer space available", "Socket is already connected",            \
        "Socket is not connected", "Can't send after socket shutdown",         \
        "Too many references: can't splice", "Operation timed out",            \
        "Connection refused", "Too many levels of symbolic links",             \
        "File name too long", "Host is down", "No route to host",              \
        "Directory not empty", "Too many processes", "Too many users",         \
        "Disc quota exceeded", "Stale NFS file handle",                        \
        "Too many levels of remote in path", "RPC struct is bad",              \
        "RPC version wrong", "RPC prog. not avail", "Program version wrong",   \
        "Bad procedure for program", "No locks available",                     \
        "Function not implemented", "Inappropriate file type or format",       \
        "Authentication error", "Need authenticator", "Device power is off",   \
        "Device error", "Value too large to be stored in data type",           \
        "Bad executable (or shared library)", "Bad CPU type in executable",    \
        "Shared library version mismatch", "Malformed Mach-o file",            \
        "Operation canceled", "Identifier removed",                            \
        "No message of desired type", "Illegal byte sequence",                 \
        "Attribute not found", "Bad message", "EMULTIHOP (Reserved)",          \
        "No message available on STREAM", "ENOLINK (Reserved)",                \
        "No STREAM resources", "Not a STREAM", "Protocol error",               \
        "STREAM ioctl timeout", "Operation not supported on socket",           \
        "Policy not found", "State not recoverable", "Previous owner died",    \
        "Interface output queue is full"                                       \
  }
#endif

#if defined __linux__
#define ERRLIST_SIZE 134
#define STR_ERRORS                                                             \
  {                                                                            \
    "No error information", "Operation not permitted",                         \
        "No such file or directory", "No such process",                        \
        "Interrupted system call", "I/O error", "No such device or address",   \
        "Argument list too long", "Exec format error", "Bad file descriptor",  \
        "No child process", "Resource temporarily unavailable",                \
        "Out of memory", "Permission denied", "Bad address",                   \
        "Block device required", "Resource busy", "File exists",               \
        "Cross-device link", "No such device", "Not a directory",              \
        "Is a directory", "Invalid argument", "Too many open files in system", \
        "No file descriptors available", "Not a tty", "Text file busy",        \
        "File too large", "No space left on device", "Invalid seek",           \
        "Read-only file system", "Too many links", "Broken pipe",              \
        "Domain error", "Result not representable",                            \
        "Resource deadlock would occur", "Filename too long",                  \
        "No locks available", "Function not implemented",                      \
        "Directory not empty", "Symbolic link loop", "No error information",   \
        "No message of desired type", "Identifier removed",                    \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "No error information", "Device not a stream", \
        "No data available", "Device timeout", "Out of streams resources",     \
        "No error information", "No error information",                        \
        "No error information", "Link has been severed",                       \
        "No error information", "No error information",                        \
        "No error information", "Protocol error", "Multihop attempted",        \
        "No error information", "Bad message",                                 \
        "Value too large for data type", "No error information",               \
        "File descriptor in bad state", "No error information",                \
        "No error information", "No error information",                        \
        "No error information", "No error information",                        \
        "No error information", "Illegal byte sequence",                       \
        "No error information", "No error information",                        \
        "No error information", "Not a socket",                                \
        "Destination address required", "Message too large",                   \
        "Protocol wrong type for socket", "Protocol not available",            \
        "Protocol not supported", "Socket type not supported",                 \
        "Not supported", "Protocol family not supported",                      \
        "Address family not supported by protocol", "Address in use",          \
        "Address not available", "Network is down", "Network unreachable",     \
        "Connection reset by network", "Connection aborted",                   \
        "Connection reset by peer", "No buffer space available",               \
        "Socket is connected", "Socket not connected",                         \
        "Cannot send after socket shutdown", "No error information",           \
        "Operation timed out", "Connection refused", "Host is down",           \
        "Host is unreachable", "Operation already in progress",                \
        "Operation in progress", "Stale file handle", "No error information",  \
        "No error information", "No error information",                        \
        "No error information", "Remote I/O error", "Quota exceeded",          \
        "No medium found", "Wrong medium type", "Operation canceled",          \
        "Required key not available", "Key has expired",                       \
        "Key has been revoked", "Key was rejected by service",                 \
        "Previous owner died", "State not recoverable",                        \
        "No error information", "No error information",                        \
  }
#endif

char* s21_strerror(int errnum) {
  const char* errors[ERRLIST_SIZE] = STR_ERRORS;
  static char result[BUFF_SIZE];
  s21_memset(result, 0, BUFF_SIZE);

  if (errnum >= 0 && errnum < ERRLIST_SIZE) {
    s21_strncpy(result, errors[errnum], BUFF_SIZE - 1);
  } else {
#if defined(__linux__)
    s21_strncpy(result, "No error information", BUFF_SIZE - 1);
#endif
#if defined(__APPLE__) || defined(__MACH__)
    sprintf(result, "Unknown error: %d", errnum);
#endif
  }

  return result;
}
